'use strict';

document.getElementById('btn').addEventListener('click', () => {
  alert('Hello from ViperCode!');
});
