# HTML5 Starter

A minimal HTML5 + CSS + JavaScript starter.

## Run

Open `index.html` in your browser, or serve the directory with any
static file server (e.g. `python -m http.server`).
