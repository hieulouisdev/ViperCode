# JavaScript Node.js App

A minimal Node.js console application starter.

## Install

```sh
npm install
```

## Run

```sh
node index.js
```
