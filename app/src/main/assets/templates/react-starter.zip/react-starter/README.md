# React Starter (mini)

A minimal React 18 + Vite starter.

## Install

```sh
npm install
```

## Run

```sh
npm run dev
```
