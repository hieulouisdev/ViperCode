# Python Console App

A minimal Python console application starter.

## Run

```sh
python main.py
```
