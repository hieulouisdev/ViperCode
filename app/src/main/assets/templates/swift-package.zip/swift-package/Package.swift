// swift-tools-version: 5.9

import PackageDescription

let package = Package(
    name: "cli-app",
    targets: [
        .executableTarget(name: "cli-app"),
    ]
)
