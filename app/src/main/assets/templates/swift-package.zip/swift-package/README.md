# Swift Package

A minimal Swift Package Manager starter.

## Build

```sh
swift build
```

## Run

```sh
swift run cli-app
```
