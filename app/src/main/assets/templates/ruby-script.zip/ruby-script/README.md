# Ruby Script

A minimal Ruby script starter.

## Run

```sh
ruby main.rb
```
