# Vite Starter (mini)

A minimal Vite vanilla TS starter.

## Install

```sh
npm install
```

## Run

```sh
npm run dev
```
