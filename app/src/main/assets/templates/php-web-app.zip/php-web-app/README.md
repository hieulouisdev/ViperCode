# PHP Web App

A minimal PHP web application starter.

## Run

```sh
php -S localhost:8000
```

Then open http://localhost:8000 in your browser.
