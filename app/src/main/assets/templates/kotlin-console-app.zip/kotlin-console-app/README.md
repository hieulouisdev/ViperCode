# Kotlin Console App

A minimal Kotlin console application starter.

## Build

```sh
./gradlew build
```

## Run

```sh
./gradlew run
```

## Structure

- `app/src/main/kotlin/Main.kt` — entry point.
- `app/build.gradle.kts` — Gradle build script.
- `settings.gradle.kts` — Gradle settings.
