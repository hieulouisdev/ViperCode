rootProject.name = "kotlin-console-app"

include(":app")
