# Rust CLI App

A minimal Rust CLI application starter.

## Build

```sh
cargo build --release
```

## Run

```sh
cargo run
```
