# Vue 3 Starter (mini)

A minimal Vue 3 + Vite starter.

## Install

```sh
npm install
```

## Run

```sh
npm run dev
```
