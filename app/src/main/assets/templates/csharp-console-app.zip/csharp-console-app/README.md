# C# Console App

A minimal C# console application starter.

## Build

```sh
dotnet build
```

## Run

```sh
dotnet run
```
