# Android Jetpack Compose Starter (mini)

A minimal Jetpack Compose Android starter.

## Build

```sh
./gradlew assembleDebug
```
