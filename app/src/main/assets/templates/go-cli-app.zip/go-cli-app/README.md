# Go CLI App

A minimal Go CLI application starter.

## Run

```sh
go run main.go
```
