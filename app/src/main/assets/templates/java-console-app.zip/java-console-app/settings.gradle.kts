rootProject.name = "java-console-app"

include(":app")
