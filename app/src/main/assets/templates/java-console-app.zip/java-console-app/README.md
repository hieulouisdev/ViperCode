# Java Console App

A minimal Java console application starter.

## Build

```sh
./gradlew build
```

## Run

```sh
./gradlew run
```
