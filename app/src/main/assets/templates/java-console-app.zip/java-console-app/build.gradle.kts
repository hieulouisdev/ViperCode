plugins {
    id("application")
    id("java")
}

repositories {
    mavenCentral()
}

application {
    mainClass.set("com.example.Main")
}
